import React, {useState} from 'react';
import axios from 'axios';
import { API_URL } from '../../api';
const Create = () => {
    const [fullname, setFullname] = useState('');
    const [email, setEmail] = useState('');
    const handleSubmit = async () => {
        await axios.post(API_URL, {
            fullname,
            email,
        })
    }
    const handleReset = (event) => {
        window.location.reload();
    }
  return (
    <div> 
        <input label="Full Name" onChange={event => setFullname(event.target.value)} placeholder='Enter Fullname'/><br/>
        <input label="Email" onChange={event => setEmail(event.target.value)} placeholder='Enter Email'/><br/>
        <button onClick={handleSubmit}>Submit</button><button onClick={handleReset}>Reset</button>
    </div>
  )
}

export default Create