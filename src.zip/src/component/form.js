import {useState} from'react';
export default function Form(){
const [name,setName]=useState('');
const [email,setEmail]=useState('');
const [password,setPassword]=useState('');
const [submitted,setSubmitted]=useState(false);
const [error,setError]=useState(false);
const handleName=(a)=>{
    setName(a.target.value);
    setSubmitted(false);
};
const handleEmail=(b)=>{
    setEmail(b.target.value);
    setSubmitted(false);
};
const handlePassword=(d)=>{
    setPassword(d.target.value);
    setSubmitted(false);
};
const handleSubmit=(e)=>{
    e.preventDefault();
    if(name===''||email===''||password===''){
    setError(true);
    }else{
    setSubmitted(true);
    setError(false);
    }
};
const successMessage=()=>{
    return(
    <div
        className="alter"
        style={{
        display:submitted?'':'none',
        }}>
        <h1>Login successfull</h1>
    </div>
    );
};
const errorMessage=()=>{
    return(
    <div
        className="error"
        style={{
        display:error?'':'none',
        }}>
        <h1>Please enter all the detail</h1>
    </div>
    );
};
return (
    <div className="form">
    <div>
        <h1>LOGIN PAGE</h1>
    </div>
    <div className="messages">
        {errorMessage()}
        {successMessage()}
    </div>
    <form>
        <label className="label">Enter your username</label>
        <input onChange={handleName} className="detail"
        value={name} type="text" />
        <label className="label">Enter your email</label>
        <input onChange={handleEmail} className="detail"
        value={email} type="email" />
        <label className="label">Enter your password</label>
        <input onChange={handlePassword} className="detail"
        value={password} type="password" />
        <button onClick={handleSubmit} className="button" type="submit">
        Submit the Detail
        </button>
    </form>
    </div>
);
}